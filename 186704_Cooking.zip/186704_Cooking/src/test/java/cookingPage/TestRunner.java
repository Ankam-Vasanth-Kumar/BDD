package cookingPage;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:/BDD704/186704_Cooking/src/test/resources/cooking/cooking.feature", glue = { "cookingPage" })
public class TestRunner {

 

}