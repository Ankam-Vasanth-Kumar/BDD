package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;





@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"C:/Users/pteegala/Downloads/187218_Coaching_Class_Enquiry/src/test/resources/coaching.feature"}, dryRun=false, glue="stepdefinition")


public class TestRunner {

}
